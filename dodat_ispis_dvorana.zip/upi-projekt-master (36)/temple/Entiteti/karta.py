class Karta():
    def __init__(self, id,datum_kupnje,vrijeme_kupnje,cijena,film_id,dvorana_id):
        self._id = id
        self._datum_kupnje = datum_kupnje
        self._vrijeme_kupnje = vrijeme_kupnje
        self._cijena=cijena
        self._film_id=film_id
        self._dvorana_id=dvorana_id

    @property
    def id(self):
        return self._id

    @property
    def datum_kupnje(self):
        return self._datum_kupnje

    @property
    def vrijeme_kupnje(self):
        return self._vrijeme_kupnje
    
    @property
    def cijena(self):
        return self._cijena
    
    @property
    def film_id(self):
        return self._film_id

    @property
    def dvorana_id(self):
        return self._dvorana_id

    
    def __str__(self):
        return """
        id: {0}
        datum_kupnje: {1}
        vrijeme_kupnje: {2}
	cijena: {3}
	film_id: {4}
	dvorana_id: {5}
        ----------------
        """.format(self._id,self._datum_kupnje,self._vrijeme_kupnje,self._cijena,self._film_id,self._dvorana_id)


