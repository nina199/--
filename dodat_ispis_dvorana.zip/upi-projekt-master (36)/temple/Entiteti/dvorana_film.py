class Dvorana_Film():
    def __init__(self, id,datum_prikaza,vrijeme_pocetka,sjedalo,film_id,dvorana_id):
        self._id = id
        self._datum_prikaza=datum_prikaza
        self._vrijeme_pocetka=vrijeme_pocetka
        self._sjedalo=sjedalo
        self._film_id=film_id
        self._dvorana_id=dvorana_id
        
    
    @property
    def id(self):
        return self._id

    @property
    def datum_prikaza(self):
        return self._datum_prikaza

    @property
    def vrijeme_pocetka(self):
        return self._vrijeme_pocetka

    @property
    def sjedalo(self):
        return self._sjedalo

    @property
    def film_id(self):
        return self._film_id
    
    @property
    def dvorana_id(self):
        return self._dvorana_id

    
    def __str__(self):
        return """
        id: {0}
        datum_prikaza: {1}
        vrijeme_pocetka: {2}
        sjedalo: {3}
        film_id: {4}
        dvorana_id: {5}
        ----------------
        """.format(self._id, self._datum_prikaza,self._vrijeme_pocetka,self._sjedalo,self._film_id,self._dvorana_id)


