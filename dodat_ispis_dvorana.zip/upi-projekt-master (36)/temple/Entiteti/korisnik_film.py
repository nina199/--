class Korisnik_Film():
    def __init__(self, id_baze,opis,originalni_naslov,drzava,trajanje,zanr,glumac,film_id,korisnik_id):
        self._id = id_baze
        self._opis=opis
        self._originalni_naslov=originalni_naslov
        self._drzava=drzava
        self._trajanje=trajanje
        self._zanr=zanr
        self._glumac=glumac
        self._film_id=film_id
        self._korisnik_id=korisnik_id
        
    
    @property
    def id_baze(self):
        return self._id

    @property
    def opis(self):
        return self._opis

    @property
    def originalni_naslov(self):
        return self._originalni_naslov

    @property
    def drzava(self):
        return self._drzava

    @property
    def trajanje(self):
        return self._trajanje

    @property
    def zanr(self):
        return self._zanr

    @property
    def glumac(self):
        return self._glumac

    @property
    def film_id(self):
        return self._film_id
    
    @property
    def korisnik_id(self):
        return self._korisnik_id

    
    def __str__(self):
        return """
        id: {0}
        opis: {1}
        originalni_naslov: {2}
        drzava: {3}
        trajanje: {4}
        zanr: {5}
        glumac: {6}
        film_id: {7}
        korisnik_id: {8}
        ----------------
        """.format(self._id, self._opis,self._originalni_naslov,self._drzava,self._trajanje,self._zanr,self._glumac,self._film_id,self._korisnik_id)


