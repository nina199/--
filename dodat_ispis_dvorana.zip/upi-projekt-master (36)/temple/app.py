from bottle import Bottle, run, \
     template, debug, get, route, static_file,request,redirect,post
import os, sys
from baza import *
from datetime import datetime
import json
import re 



unesi_demo_podatke()

#Globalne varijable
sugovornik=0
id_kina_koja_je_odabrano=0
id_dvorane_koja_je_odabrana=0
korisnik_logiran=False
korisnik_koji_je_prijavljen=None
odabrani_film=None
odabrana_dvorana=None
link_na_video=None

#Putanja
dirname = os.path.dirname(sys.argv[0])
template_path = dirname + '\\views'
app = Bottle()
debug(True)

@app.route('/static/<filename:re:.*\.css>')
def send_css(filename):
    return static_file(filename, root=dirname+'/static/assets/css')

@app.route('/static/<filename:re:.*\.css.map>')
def send_cssmap(filename):
    return static_file(filename, root=dirname+'/static/assets/css')

@app.route('/static/<filename:re:.*\.js>')
def send_js(filename):
    return static_file(filename, root=dirname+'/static/assets/js')

@app.route('/static/<filename:re:.*\.js.map>')
def send_jsmap(filename):
    return static_file(filename, root=dirname+'/static/assets/js')



@app.route('/')
def index():
    data=procitaj_sve_podatke_film()
    return template('index',data=data,form_akcija='/pretrazivanje',template_lookup=[template_path])

@app.route('/pretrazivanje',method='POST')
def pretrazivanje():
    postdata=request.body.read()
    unos=str(request.forms.get('search')).lower()
    if unos=="":
        redirect('/')
    filmovi=procitaj_sve_podatke_film()
    data=[]
    for f in filmovi:
        match = re.search(unos, f.naziv.lower())
        if match:
            data.append(f)
    kina=procitaj_sve_podatke_kina()
    for k in kina:
        match=re.search(unos,k.naziv.lower())
        if match:
            filmovi=dohvati_filmove_koji_su_u_kinu(k.id)
            for f in filmovi:
                data.append(f)
    return template('index',data=data,form_akcija='/pretrazivanje',template_lookup=[template_path])

@app.route('/kontakt')
def kontakt():
    return template('kontakt',template_lookup=[template_path])

@app.route('/karta')
def karta():
    return template('karta',template_lookup=[template_path])

@app.route('/pregled_sjedala')
def pregled_sjedala():
    return template('pregled_sjedala',template_lookup=[template_path])



@app.route('/filmovi/<ind>')
def filmovi(ind):
    index=ind
    kf=dohvati_kf_po_film_id(index)
    lista=[]
    try:
        index=int(index)
    except Exception as e:
        if(korisnik_logiran):
            redirect('/korisnicki_profil')
        else:
            redirect('/login')

    for f in kf:
        film=dohvati_film_po_id(index)
        korisnik=dohvati_korisnika_po_id(f.korisnik_id)
        x={
            "id_baze": f.id_baze,
            "opis": f.opis,
            "originalni_naslov": f.originalni_naslov,
            "drzava": f.drzava,
            "trajanje": f.trajanje,
            "zanr": f.zanr,
            "glumac": f.glumac,
            "film_id": f.film_id,
            "korisnik_id": f.korisnik_id,
            "film_naziv": film.naziv,
            "korisnik_user_name": korisnik.korisnicko_ime                 
        }
        lista.append(x)
        
    return template('filmovi',lista=lista,template_lookup=[template_path])


@app.route('/pregled_sjedala/<ind>')



@app.route('/login')
def login():
    if(korisnik_logiran!=True):
        return template('login',form_akcija="/provjera_korisnickog_profila",zastavica= False,korisnik_logiran=False,template_lookup=[template_path])
    else:
        return provjera_korisnickog_profila()


@app.route('/provjera_korisnickog_profila',method="POST")
def provjera_korisnickog_profila():
    global korisnik_logiran
    global korisnik_koji_je_prijavljen
    userID=-1
    lista=[]
    if korisnik_logiran==False:
        postdata=request.body.read()
        username=request.forms.get('user_name')
        lozinka=str(request.forms.get('password'))
        svi_korisnici=procitaj_sve_podatke_korisnik()
        for korisnik in svi_korisnici:
            print(korisnik.korisnicko_ime)
            if (korisnik.korisnicko_ime==username ):
                if (korisnik.lozinka==lozinka):
                    userID=korisnik.id
                    print("Uspješno ste se prijavili u svoj profil!"+korisnik.ime)
                    lista=dohvati_korisnicki_profil(korisnik)
                    korisnik_logiran=True
                    korisnik_koji_je_prijavljen=korisnik
                    return template('korisnicki_profil',data=korisnik,lista=lista,korisnik_logiran=korisnik_logiran,template_lookup=[template_path])

                else:
                    return template('login',form_akcija="/provjera_korisnickog_profila",korisnik_logiran=False,zastavica=True,template_lookup=[template_path])
    else:
        lista=dohvati_korisnicki_profil(korisnik_koji_je_prijavljen)
        return template('korisnicki_profil',data=korisnik_koji_je_prijavljen,lista=lista,korisnik_logiran=korisnik_logiran,template_lookup=[template_path])
    if userID==-1:
        return template('login',form_akcija="/provjera_korisnickog_profila",zastavica=True,korisnik_logiran=False,template_lookup=[template_path])

@app.route('/reg')
def reg():
    podaci=ispisi_korisnike_po_username()
    return template('reg', form_akcija="/dodavanje_novog_korisnika",zastavica=False,korisnik_logiran=False,template_lookup=[template_path])

@app.route('/dodavanje_novog_korisnika',method='POST')
def dodavanje_novog_korisnika():
    global korisnik_logiran
    global korisnik_koji_je_prijavljen
    postdata= request.body.read()
    svi_korisnici=procitaj_sve_podatke_korisnik()
    user_id=-1
    #Dohvacanje unesenih podataka
    ime=request.forms.get('txt_reg_ime')
    prezime=request.forms.get('txt_reg_prezime')
    spol=request.forms.get('reg_spol')
    user_name=request.forms.get('txt_reg_user')
    lozinka=request.forms.get('reg_lozinka')
    
    user_vec_postoji= False
    
    for korisnik in svi_korisnici:
        user_id=korisnik.id
        if korisnik.korisnicko_ime==user_name:
            user_vec_postoji= True
        
    if (user_vec_postoji == False):
        sacuvaj_novog_korisnika(ime,prezime,spol,user_name,lozinka)
        print("Novi korisnik uspješno spremljen!")
        svi_korisnici=procitaj_sve_podatke_korisnik()
    else:
        print("Ponovite upis!")
        return template('reg',form_akcija="/dodavanje_novog_korisnika",zastavica=True,korisnik_logiran=False,template_lookup=[template_path])
        
    for korisnik in svi_korisnici:
        if korisnik.korisnicko_ime==user_name:
            korisnik_koji_je_prijavljen=korisnik
            korisnik_logiran=True
            data=korisnik_koji_je_prijavljen
            lista=dohvati_korisnicki_profil(data)
            return template('korisnicki_profil',data=data,lista=lista,form_akcija="",template_lookup=[template_path])

@app.route('/korisnicki_profil')
def korisnicki_profil():
    data=korisnik_koji_je_prijavljen
    lista=dohvati_korisnicki_profil(data)
    return template('korisnicki_profil',data=data,lista=lista,form_akcija="",template_lookup=[template_path])

def dohvati_korisnicki_profil(korisnik):
    global korisnik_logiran
    global korisnik_koji_je_prijavljen
    korisnik_film=dohvati_kf_po_korisnik_id(korisnik.id)
    print("U metodi dohvati korisnicki profil")
    lista=[]

    for f in korisnik_film:
        film=dohvati_film_po_id(f.film_id)
        x={
            "id_baze": f.id_baze,
            "opis": f.opis,
            "originalni_naslov": f.originalni_naslov,
            "drzava": f.drzava,
            "trajanje": f.trajanje,
            "zanr": f.zanr,
            "glumac": f.glumac,
            "film_id": f.film_id,
            "korisnik_id": f.korisnik_id,
            "film_naziv": film.naziv,
            "korisnik_user_name": korisnik.korisnicko_ime                 
        }
        y=json.dumps(x)
        print(y)
        lista.append(x)
        korisnik_logiran=True
        korisnik_koji_je_prijavljen=korisnik
    return lista

@app.route('/korisnicki_profil_dvor')
def korisnicki_profil_dvor():
    data=korisnik_koji_je_prijavljen
    lista=dohvati_korisnicki_profil_dvor(data)
    return template('korisnicki_profil_dvor',data=data,lista=lista,form_akcija="",template_lookup=[template_path])

def dohvati_korisnicki_profil_dvor(korisnik):
    global korisnik_logiran
    global korisnik_koji_je_prijavljen
    korisnik_film=dohvati_kf_po_korisnik_id(korisnik.id)
    print("U metodi dohvati korisnicki profil")
    lista=[]

    for f in korisnik_film:
        film=dohvati_film_po_id(f.film_id)
        x={
            "id_baze": f.id_baze,
            "opis": f.opis,
            "originalni_naslov": f.originalni_naslov,
            "drzava": f.drzava,
            "trajanje": f.trajanje,
            "zanr": f.zanr,
            "glumac": f.glumac,
            "film_id": f.film_id,
            "korisnik_id": f.korisnik_id,
            "film_naziv": film.naziv,
            "korisnik_user_name": korisnik.korisnicko_ime                 
        }
        y=json.dumps(x)
        print(y)
        lista.append(x)
        korisnik_logiran=True
        korisnik_koji_je_prijavljen=korisnik
    return lista

#KINO#
@app.route('/odabiranje_kina')
def odabiranje_kina():
    podaci=procitaj_sve_podatke_kina()
    return template('odabiranje_kina',data=podaci,form_akcija="trazi_film_za_kino",template_lookup=[template_path])

@app.route('/trazi_film_za_kino',method='POST')
def trazi_film_za_kino():
    global id_kina_koje_je_odabrano
    postdata= request.body.read()
    kino=request.forms.get('selectbasic')
    if(kino==None):
        kino=dohvati_kino_po_id(id_kina_koje_je_odabrano)
    else:
        id_kina_koje_je_odabrano=int(kino)
    film=dohvati_filmove_koji_su_u_kinu(id_kina_koje_je_odabrano)
    return template('odaberi_film',film=film,kino_id=id_kina_koje_je_odabrano,form_akcija="/dodavanje_obiljezja_filma",template_lookup=[template_path])


#DVORANA#
@app.route('/odabiranje_dvorane')
def odabiranje_dvorane():
    podaci=procitaj_sve_podatke_dvorana()
    return template('odabiranje_dvorane',data=podaci,form_akcija="dodavanje_obiljezja_projekcije",template_lookup=[template_path])

@app.route('/dodavanje_obiljezja_projekcije')
def dodavanje_obiljezja_projekcije():
    global odabrana_dvorana
    postdata=request.body.read()
    dvorana=request.forms.get('odabrana_dvorana')
    odabrana_dvorana=dvorana
    return template('dodavanje_obiljezja_projekcije',dvorana=dvorana,form_akcija="/spremanje_obiljezja_projekcije",template_lookup=[template_path])

@app.route('/spremanje_obiljezja_projekcije',method='POST')
def spremanje_obiljezja_projekcije():
    postdata=request.body.read()
    dvorana_id=odabrana_dvorana
    datum_prikaza=request.forms.get('datum_prikaza')
    vrijeme_pocetka=request.forms.get('vrijeme_pocetka')
    sjedalo=request.forms.get('sjedalo')
    sacuvaj_novog_df(datum_prikaza,vrijeme_pocetka,sjedalo,dvorana_id,korisnik_koji_je_prijavljen.id)
    return korisnicki_profil_dvor()


#FILM#
@app.route('/odaberi_film',method='POST')
def odaberi_film():
    return template('odaberi_film',form_akcija="/dodavanje_obiljezja_filma",template_lookup=[template_path])

@app.route('/dodavanje_obiljezja_filma',method='POST')
def dodavanje_obiljezja_filma():
    global odabrani_film
    global link_na_video
    postdata=request.body.read()
    film=request.forms.get('odabrani_film')
    odabrani_film=film
    link_na_video=dohvati_film_po_id(film).link_videa
    return template('dodavanje_obiljezja_filma',film=film,link_videa=link_na_video,form_akcija="/spremanje_obiljezja_filma",template_lookup=[template_path])

@app.route('/spremanje_obiljezja_filma',method='POST')
def spremanje_obiljezja_filma():
    postdata=request.body.read()
    film_id=odabrani_film
    link_videa=request.forms.get('link_videa')
    opis=request.forms.get('opis')
    originalni_naslov=request.forms.get('originalni_naslov')
    drzava=request.forms.get('drzava')
    trajanje=request.forms.get('trajanje')
    zanr=request.forms.get('zanr')
    glumac=request.forms.get('glumac')
    sacuvaj_novog_kf(opis,originalni_naslov,drzava,trajanje,zanr,glumac,film_id,korisnik_koji_je_prijavljen.id)
    
    return korisnicki_profil()


#DODAJ NOVI FILM# 
@app.route('/dodaj_novi_film')
def dodaj_novi_film():
    return template('dodaj_novi_film',form_akcija="spremanje_novog_filma",template_lookup=[template_path])

@app.route('/spremanje_novog_filma',method='POST')
def spremanje_novog_filma():
    postdata=request.body.read()
    naziv_filma=request.forms.get('naziv_novog_filma')
    link=request.forms.get('link_na_video')

    sacuvaj_novi_film(naziv_filma,link,id_kina_koje_je_odabrano)
    return trazi_film_za_kino()

@app.route('/odjava')
def odjava():
    global korisnik_koji_je_prijavljen
    global korisnik_logiran
    korisnik_logiran=False
    korisnik_koji_je_prijavljen=None
    
    redirect('/login')
    #return template('index',data=data,template_lookup=[template_path])

@app.route('/postavke_profila')
def postavke_profila():
    podaci=korisnik_koji_je_prijavljen
    return template('postavke_profila',data=podaci,form_akcija='/spremi_promjene',template_lookup=[template_path])

@app.route('/spremi_promjene',method='POST')
def spremi_promjene():
    postdata=request.body.read()
    ime=request.forms.get('txt_reg_ime')
    prezime=request.forms.get('txt_reg_prezime')
    spol=request.forms.get('reg_spol')
    lozinka=request.forms.get('reg_lozinka')

    azuriraj_korisnika(korisnik_koji_je_prijavljen.id,ime,prezime,spol,lozinka)
    return korisnicki_profil()


@app.route('/azuriranje_posta')
def azuriranje_posta():
    id_posta=int(request.query['postid'])

    data=dohvati_kf_po_id(id_posta)
    return template('azuriranje_posta',data=data,form_akcija='/spremi_azurirane_podatke',template_lookup=[template_path])

@app.route('/spremi_azurirane_podatke',method='POST')
def spremi_azurirane_podatke():
    postdata=request.body.read()
    filmid=request.forms.get('filmid')
    postid=request.forms.get('postid')
    opis=request.forms.get('opis')
    originalni_naslov=request.forms.get('originalni_naslov')
    drzava=request.forms.get('drzava')
    trajanje=request.forms.get('trajanje')
    zanr=request.forms.get('zanr')
    glumac=request.forms.get('glumac')

    azuriraj_kf(postid,opis,originalni_naslov,drzava,trajanje,zanr,glumac,filmid,korisnik_koji_je_prijavljen.id)
    print("Spremljeni podaci!")
    redirect('/korisnicki_profil')

@app.route('/izbrisi_post')
def izbrisi_post():
    id_posta=int(request.query['postid'])
    izbrisi_kf(id_posta)
    redirect('/korisnicki_profil')

run(app, host='localhost', port = 8080)

