print("Hello world")

