import unittest
import os, sys, sqlite3, datetime

from baza import *
dirname = os.path.dirname(sys.argv[0])
from korisnik import Korisnik

class TestStringMethods(unittest.TestCase):

    def test_init_value_error_lozinka(self):
        with self.assertRaises(ValueError):
            Korisnik("","","","","123","")

    def test_init_ime_error(self):
        with self.assertRaises(ValueError):
            Korisnik("m","","","","","")

    def test_init_korisnicko_ime_error(self):
        with self.assertRaises(ValueError):
            Korisnik("","", "","n vidovic","","")

    
        
        

unittest.main()
