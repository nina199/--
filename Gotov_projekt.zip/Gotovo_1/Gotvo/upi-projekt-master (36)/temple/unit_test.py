import sys
import os
import unittest
from itertools import permutations
from baza import *
if __name__=='__main__':
    sys.path.append(os.path.abspath(".."))

class TestTrokut(unittest.TestCase):      
    def setUp(self):
        unesi_demo_podatke()
    def tearDown(self):
        os.remove("upi_projekt.db")
    
    def test_select_kino_po_nazivu_ispravno(self):
        sacuvaj_novo_kino('Cineplexx')
        self.assertCountEqual([dohvati_kino_po_nazivu('Cineplexx').naziv],['Cineplexx']) 

    def test_select_kino_po_nazivu_krivo(self):
        sacuvaj_novo_kino("Cineplexx")
        self.assertIsNone(dohvati_kino_po_nazivu('ime'))   
        
    def test_select_kino_po_id_ispravno(self):
        sacuvaj_novo_kino("Cineplexx")
        d=dohvati_kino_po_id(1)
        self.assertCountEqual([d.id],[1])

    def test_select_kino_po_id_krivo(self):
        sacuvaj_novo_kino('Cineplexx')
        self.assertIsNone(dohvati_kino_po_id('ime'))

    def test_update_kino_ispravno(self):
        sacuvaj_novo_kino("Cineplexx")
        azuriraj_kino(1,'Cinestar')
        dd=procitaj_sve_podatke_kina()
        for d in dd:
            self.assertCountEqual([(d.id,d.naziv)],[(1,'Cinestar')])   

    def test_delete_kino(self):
        sacuvaj_novo_kino('Cineplexx')
        sacuvaj_novo_kino('Cinestar')
        izbrisi_kino(1)
        dd=procitaj_sve_podatke_kina()
        for d in dd:
            self.assertCountEqual((d.id,d.naziv), (2,'Cinestar'))

    def test_insert_kino(self):
        sacuvaj_novo_kino('Cineplexx')
        sacuvaj_novo_kino('Cinestar')
        self.assertCountEqual([dohvati_kino_po_nazivu('Cineplexx').id], [1])
        self.assertCountEqual([dohvati_kino_po_nazivu('Cinestar').id],[2])

    
if __name__=='__main__':
    unittest.main()
