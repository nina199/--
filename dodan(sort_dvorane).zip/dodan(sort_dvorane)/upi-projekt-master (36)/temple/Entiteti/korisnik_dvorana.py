class Korisnik_Dvorana():
    def __init__(self, id_baza,datum_prikaza,vrijeme_pocetka,sjedalo,dvorana_id,korisnik_id):
        self._id = id_baza
        self._datum_prikaza=datum_prikaza
        self._vrijeme_pocetka=vrijeme_pocetka
        self._sjedalo=sjedalo
        self._dvorana_id=dvorana_id
        self._korisnik_id=korisnik_id
        
    
    @property
    def id_baza(self):
        return self._id

    @property
    def datum_prikaza(self):
        return self._datum_prikaza

    @property
    def vrijeme_pocetka(self):
        return self._vrijeme_pocetka

    @property
    def sjedalo(self):
        return self._sjedalo

    @property
    def dvorana_id(self):
        return self._dvorana_id
    
    @property
    def korisnik_id(self):
        return self._korisnik_id

    
    def __str__(self):
        return """
        id: {0}
        datum_prikaza: {1}
        vrijeme_pocetka: {2}
        sjedalo: {3}
        dvorana_id: {4}
        korisnik_id: {5}
        ----------------
        """.format(self._id, self._datum_prikaza,self._vrijeme_pocetka,self._sjedalo,self._dvorana_id,self._korisnik_id)


