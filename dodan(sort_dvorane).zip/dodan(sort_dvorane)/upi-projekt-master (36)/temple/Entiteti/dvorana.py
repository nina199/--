class Dvorana():
    def __init__(self, id, naziv,broj_mjesta,id_kino):
        self._id = id
        self._naziv = naziv
        self._broj_mjesta =broj_mjesta
        self._id_kino=id_kino

    @property
    def id(self):
        return self._id

    @property
    def naziv(self):
        return self._naziv

    @property
    def broj_mjesta(self):
        return self._broj_mjesta
	
    def __str__(self):
        return """
        id: {0}
        naziv: {1}
        broj_mjesta: {2}
		id_kino: {3}
        ----------------
        """.format(self._id, self._naziv, self._broj_mjesta, self._id_kino)


