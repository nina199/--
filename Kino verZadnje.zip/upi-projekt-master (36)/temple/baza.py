import sqlite3
import os, sys
from datetime import datetime


dirname = os.path.dirname(sys.argv[0])
sys.path.append(dirname.replace('\\', '/') + '/Entiteti/')

from film import Film
from kino import Kino
from korisnik import Korisnik
from korisnik_film import Korisnik_Film

def unesi_demo_podatke():
    conn = sqlite3.connect("upi_projekt.db")

    try:
        
        cur = conn.cursor()
        cur.executescript("""

        CREATE TABLE IF NOT EXISTS kino (
        id INTEGER PRIMARY KEY,
        naziv text NOT NULL);

        CREATE TABLE IF NOT EXISTS film (
        id_film INTEGER PRIMARY KEY,
        naziv text NOT NULL,
        link_videa text NOT NULL,
        id_kino INTEGER NOT NULL,
        FOREIGN KEY (id_kino) REFERENCES drzava (id)
        );

        
        CREATE TABLE IF NOT EXISTS korisnik (
        id_korisnik INTEGER PRIMARY KEY,
        ime text NOT NULL,
        prezime text NOT NULL,
        spol text NOT NULL,
        korisnicko_ime text NOT NULL,
        lozinka text NOT NULL
        );


        CREATE TABLE IF NOT EXISTS korisnik_film (
        id_baze INTEGER PRIMARY KEY,
        opis text NOT NULL,
        originalni_naslov text NOT NULL,
        drzava text NOT NULL,
        trajanje INTEGER NOT NULL,
        zanr text NOT NULL,
        glumac text NOT NULL,
        film_id INTEGER NOT NULL,
        korisnik_id INTEGER NOT NULL,
        FOREIGN KEY (film_id) REFERENCES film (id_film),
        FOREIGN KEY (korisnik_id) REFERENCES korisnik (id_korisnik)
        )
        """)
        #cur.execute("INSERT INTO kino (naziv) VALUES (?)", ('Cinestar'))
        #cur.execute("INSERT INTO kino (naziv) VALUES (?)", ('Cineplexx'))

        #cur.execute("INSERT INTO film (naziv, link_videa,id_kino) VALUES (?,?,?)", ('Male žene','https://www.youtube.com/watch?v=MYnZ0aMlKVI',1))
        #cur.execute("INSERT INTO film (naziv, link_videa,id_kino) VALUES (?,?,?)", ('1917','https://www.youtube.com/watch?v=gZjQROMAh_s',2))
        
        
        conn.commit()

        print("uspjesno uneseni testni podaci!")

    except Exception as e: 
        print("Dogodila se greska pri kreiranju demo podataka: ", e)
        conn.rollback()
        
    conn.close()
############# tablica KINO ######################    
def procitaj_sve_podatke_kina():
    conn = sqlite3.connect("upi_projekt.db")
    lista_kina = []
    try:
        cur = conn.cursor()
        cur.execute(""" SELECT id, naziv FROM kino """)        
        podaci = cur.fetchall()        
        for kin in podaci:
            # 0 - id
            # 1 - naziv
            k = Kino(kin[0], kin[1])
            print(k)
            lista_kina.append(k)

        print("uspjesno dohvaceni svi podaci iz tablice kina!")


    except Exception as e: 
        print("Dogodila se greska pri dohvacanju svih podataka iz tablice kina: ", e)
        conn.rollback()

    conn.close()
    return lista_kina
    
def sacuvaj_novo_kino(naziv):
    conn = sqlite3.connect("upi_projekt.db")
    try:

        cur = conn.cursor()
        cur.execute("INSERT INTO kino (naziv) VALUES (?)", ([naziv]))
        conn.commit()

        print("uspjesno dodano novo kino u bazu podataka")

    except Exception as e: 
        print("Dogodila se greska pri dodavanju novog kina u bazu podataka: ", e)
        conn.rollback()

    conn.close()
    
def dohvati_kino_po_nazivu(naziv):
    conn =sqlite3.connect("upi_projekt.db")
    kino = None
    try:
        cur =conn.cursor()
        cur.execute(" SELECT id,naziv FROM kino WHERE naziv = ?", ([naziv]))
        podaci = cur.fetchone()

        print("podaci", podaci)
        kino = Kino(podaci[0], podaci[1])

    except Exception as e: 
        print("Dogodila se greska pri dohvacanju kina po nazivu iz baze podataka: ", e)
        conn.rollback()

    conn.close()
    return kino

def izbrisi_kino(kino_id):
    conn = sqlite3.connect("upi_projekt.db")
    try:

        cur = conn.cursor()
        cur.execute("DELETE FROM kino WHERE id=?;", (str(kino_id)))
        conn.commit()

        print("uspjesno izbrisno kino iz baze podataka")

    except Exception as e: 
        print("Dogodila se greska pri brisanju kina iz baze podataka: ", e)
        conn.rollback()

    conn.close()

def dohvati_kino_po_id(kino_id):
    conn = sqlite3.connect("upi_projekt.db")
    kino = None
    try:

        cur = conn.cursor()
        cur.execute(" SELECT id,naziv FROM kino WHERE id= ?", ([str(kino_id)]))
        podaci = cur.fetchone()

        print("podaci", podaci)
        kino = Kino(podaci[0], podaci[1])

        print("uspjesno dohvaceno kino iz baze podataka po ID-u")

    except Exception as e: 
        print("Dogodila se greska pri dohvacanju kina iz baze podataka po ID-u: ", e)
        conn.rollback()

    conn.close()
    return kino

def azuriraj_kino(kino_id,naziv):
    conn = sqlite3.connect("upi_projekt.db")
    try:

        cur = conn.cursor()
        cur.execute("UPDATE kino SET naziv = ? WHERE id = ?", (naziv,str(kino_id)))
        conn.commit()

        print("uspjesno ažurirano kino iz baze podataka")

    except Exception as e: 
        print("Dogodila se greska pri ažuriranju kina iz baze podataka: ", e)
        conn.rollback()

    conn.close()
    
################## tablica FILM ####################
def procitaj_sve_podatke_film():
    conn = sqlite3.connect("upi_projekt.db")
    lista_filmova = []
    try:
        cur = conn.cursor()
        cur.execute(""" SELECT id_film, naziv, link_videa, id_kino FROM film """)        
        podaci = cur.fetchall()        
        for film in podaci:
            # 0 - id
            # 1 - naziv
            # 2 - link_videa
            # 3 - id_kino
            f = Film(film[0], film[1], film[2], film[3])
            lista_filmova.append(f)

        print("uspjesno dohvaceni svi podaci iz tablice filmova!")

        for f in lista_filmova:
            print(f)

    except Exception as e: 
        print("Dogodila se greska pri dohvacanju svih podataka iz tablice filmova: ", e)
        conn.rollback()

    conn.close()
    return lista_filmova

def sacuvaj_novi_film(naziv,link_videa,id_kino):
    conn = sqlite3.connect("upi_projekt.db")
    try:

        cur = conn.cursor()
        cur.execute("INSERT INTO film (naziv,link_videa,id_kino) VALUES (?,?,?)", (naziv,link_videa,str(id_kino)))
        conn.commit()

        print("uspjesno dodana novi film u bazu podataka")

    except Exception as e: 
        print("Dogodila se greska pri dodavanju novog filma u bazu podataka: ", e)
        conn.rollback()

    conn.close()

def izbrisi_film(film_id_):
    conn = sqlite3.connect("upi_projekt.db")
    try:

        cur = conn.cursor()
        cur.execute("DELETE FROM film WHERE id_film=?;", (str(film_id_)))
        conn.commit()

        print("uspjesno izbrisan film iz baze podataka")

    except Exception as e: 
        print("Dogodila se greska pri brisanju filma iz baze podataka: ", e)
        conn.rollback()

    conn.close()

def dohvati_film_po_id(film_id):
    conn = sqlite3.connect("upi_projekt.db")
    film = None
    try:

        cur = conn.cursor()
        cur.execute(" SELECT id_film,naziv,link_videa,id_kino FROM film WHERE id_film= ?", ([str(film_id)]))
        podaci = cur.fetchone()

        print("podaci", podaci)
        film = Film(podaci[0], podaci[1],podaci[2],podaci[3])

        print("uspjesno dohvacen film iz baze podataka po ID-u")

    except Exception as e: 
        print("Dogodila se greska pri dohvacanju filma iz baze podataka po ID-u: ", e)
        conn.rollback()

    conn.close()
    return film

def dohvati_filmove_koji_su_u_kinu(kino_id):
    conn = sqlite3.connect("upi_projekt.db")
    lista_filmova = []
    try:
        cur = conn.cursor()
        cur.execute(""" SELECT id_film, naziv, link_videa, id_kino FROM film WHERE id_kino= ? """,([str(kino_id)]))        
        podaci = cur.fetchall()        
        for film in podaci:
            # 0 - id
            # 1 - naziv
            # 2 - link_slike
            # 3 - id_drzava
            f = Film(film[0], film[1], film[2], film[3])
            lista_filmova.append(f)

        print("uspjesno dohvaceni svi podaci iz tablice filmova!")

        for f in lista_filmova:
            print(f)

    except Exception as e: 
        print("Dogodila se greska pri dohvacanju svih podataka iz tablice filmova: ", e)
        conn.rollback()

    conn.close()
    return lista_filmova

def azuriraj_film(film_id,naziv,link,kino_id):
    conn = sqlite3.connect("upi_projekt.db")
    try:

        cur = conn.cursor()
        cur.execute("UPDATE film SET naziv = ?, link_videa = ? ,id_kino = ? WHERE id_film = ?", (naziv,link,kino_id,str(film_id)))
        conn.commit()

        print("uspjesno ažuriran film iz baze podataka")

    except Exception as e: 
        print("Dogodila se greska pri ažuriranju filma iz baze podataka: ", e)
        conn.rollback()

    conn.close()

################### tablica KORISNIK ##############################

def procitaj_sve_podatke_korisnik():
    conn = sqlite3.connect("upi_projekt.db")
    lista_korisnika = []
    try:
        cur = conn.cursor()
        cur.execute(""" SELECT id_korisnik,ime,prezime,spol,korisnicko_ime,lozinka FROM korisnik """)        
        podaci = cur.fetchall()        
        for k in podaci:
            # 0 - id
            # 1 - ime
            # 2 - prezime
            # 3 - spol
            # 4 - korisnicko_ime
            # 5 - lozinka
            d = Korisnik(k[0], k[1],k[2],k[3],k[4],k[5])
            lista_korisnika.append(d)

        print("uspjesno dohvaceni svi podaci iz tablice korisnik!")

        for p in lista_korisnika:
            print(p)

    except Exception as e: 
        print("Dogodila se greska pri dohvacanju svih podataka iz tablice korisnik: ", e)
        conn.rollback()

    conn.close()
    return lista_korisnika

def ispisi_korisnike_po_username():
    con = sqlite3.connect("upi_projekt.db")
    lista=[]
    try:
        cur =con.cursor()
        cur.execute(""" SELECT korisnicko_ime  FROM korisnik """)
        podaci=cur.fetchall()
        for user in podaci:
            lista.append(user)
    except Exception as e:
        print("Pogreška prilikom dohvaćanja svih korisničkih imena iz baze podataka",e)
        conn.rollback()
    con.close()
    return lista

def sacuvaj_novog_korisnika(ime,prezime,spol,korisnicko_ime,loz):
    conn = sqlite3.connect("upi_projekt.db")
    try:

        cur = conn.cursor()
        cur.execute("INSERT INTO korisnik (ime,prezime,spol,korisnicko_ime,lozinka) VALUES (?,?,?,?,?)", (ime,prezime,spol,korisnicko_ime,loz))
        conn.commit()

        print("uspjesno dodan novi korisnik u bazu podataka")

    except Exception as e: 
        print("Dogodila se greska pri dodavanju novog korisnika u bazu podataka: ", e)
        conn.rollback()

    conn.close()

def izbrisi_korisnika(id_):
    conn = sqlite3.connect("upi_projekt.db")
    try:

        cur = conn.cursor()
        cur.execute("DELETE FROM korisnik WHERE id_korisnik=?;", ([str(id_)]))
        conn.commit()

        print("uspjesno izbrisan korisnik iz baze podataka")

    except Exception as e: 
        print("Dogodila se greska pri brisanju korisnika iz baze podataka: ", e)
        conn.rollback()

    conn.close()

def dohvati_korisnika_po_id(id_):
    conn = sqlite3.connect("upi_projekt.db")
    korisnik = None
    try:

        cur = conn.cursor()
        cur.execute(" SELECT id_korisnik, ime, prezime,spol,korisnicko_ime,lozinka FROM korisnik WHERE id_korisnik = ?", ([str(id_)]))
        podaci = cur.fetchone()

        print("podaci", podaci)
        korisnik = Korisnik(podaci[0], podaci[1],podaci[2],podaci[3],podaci[4],podaci[5])

        print("uspjesno dohvacena korisnik iz baze podataka po ID-u")

    except Exception as e: 
        print("Dogodila se greska pri dohvacanju korisnika iz baze podataka po ID-u: ", e)
        conn.rollback()

    conn.close()
    return korisnik

def azuriraj_korisnika(id_korisnika,ime,prezime,spol,lozinka):
    conn = sqlite3.connect("upi_projekt.db")
    try:

        cur = conn.cursor()
        cur.execute("UPDATE korisnik SET ime = ?, prezime = ?, spol = ?, lozinka = ? WHERE id_korisnik = ?", (ime,prezime,spol,lozinka,str(id_korisnika)))
        conn.commit()

        print("uspjesno ažuriran korisnik iz baze podataka")

    except Exception as e: 
        print("Dogodila se greska pri ažuriranju korisnika iz baze podataka: ", e)
        conn.rollback()

    conn.close()

############# tablica KORISNIK_FILM ######################    
def procitaj_sve_podatke_kf():
    conn = sqlite3.connect("upi_projekt.db")
    lista_kf = []
    try:
        cur = conn.cursor()
        cur.execute(""" SELECT id_baze,opis,originalni_naslov,drzava,trajanje,zanr,glumac,film_id,korisnik_id FROM korisnik_film """)        
        podaci = cur.fetchall()        
        for k in podaci:
            # 0 - id
            # 1 - naziv
            d = Korisnik_Film(k[0], k[1], k[2], k[3], k[4], k[5], k[6], k[7], k[8])
            lista_kg.append(d)

        print("uspjesno dohvaceni svi podaci iz tablice korisnik_film!")

        for p in lista_kf:
            print(p)

    except Exception as e: 
        print("Dogodila se greska pri dohvacanju svih podataka iz tablice korisnik_film: ", e)
        conn.rollback()

    conn.close()
    return lista_kf
     
def sacuvaj_novog_kf(opis,originalni_naslov,drzava,trajanje,zanr,glumac,film_id,korisnik_id):
    conn = sqlite3.connect("upi_projekt.db")
    try:

        cur = conn.cursor()
        cur.execute("INSERT INTO korisnik_film (opis,originalni_naslov,drzava,trajanje,zanr,glumac,film_id,korisnik_id) VALUES(?,?,?,?,?,?,?,?)",(opis,originalni_naslov,drzava,trajanje,zanr,glumac,film_id,korisnik_id))        
        conn.commit()

        print("uspjesno dodan novi korisnik_film u bazu podataka")

    except Exception as e: 
        print("Dogodila se greska pri dodavanju novog korisnik_filma u bazu podataka: ", e)
        conn.rollback()

    conn.close()

def izbrisi_kf(kf_id):
    conn = sqlite3.connect("upi_projekt.db")
    try:
        cur = conn.cursor()
        cur.execute("DELETE FROM korisnik_film WHERE id_baze=?;", ([str(kf_id)]))
        conn.commit()

        print("uspjesno izbrisan korisnik_film iz baze podataka")

    except Exception as e: 
        print("Dogodila se greska pri brisanju korisnik_filma iz baze podataka: ", e)
        conn.rollback()

    conn.close()

def dohvati_kf_po_id(kf):
    conn = sqlite3.connect("upi_projekt.db")
    podatak = None
    try:

        cur = conn.cursor()
        cur.execute(" SELECT * FROM korisnik_film WHERE id_baze = ?", (str(kf)))
        k = cur.fetchone()

        print("podaci", k)
        podatak= Korisnik_Film(k[0], k[1], k[2], k[3], k[4], k[5], k[6], k[7], k[8])

        print("uspjesno dohvacen korisnik_film iz baze podataka po ID-u")

    except Exception as e: 
        print("Dogodila se greska pri dohvacanju korisnik_filma iz baze podataka po ID-u: ", e)
        conn.rollback()

    conn.close()
    return podatak

def azuriraj_kf(id_baze,opis,originalni_naslov,drzava,trajanje,zanr,glumac,film_id,korisnik_id):
    conn = sqlite3.connect("upi_projekt.db")
    try:

        cur = conn.cursor()
        cur.execute("UPDATE korisnik_film SET opis = ?,originalni_naslov = ?, drzava = ?, trajanje = ?, zanr = ?,glumac = ?,film_id = ?,korisnik_id = ?  WHERE id_baze = ?", (opis,originalni_naslov,drzava,trajanje,zanr,glumac,film_id,korisnik_id,id_baze))
        conn.commit()

        print("uspjesno ažuriran korisnik_film iz baze podataka")

    except Exception as e: 
        print("Dogodila se greska pri ažuriranju korisnik_filma iz baze podataka: ", e)
        conn.rollback()

    conn.close()

def dohvati_kf_po_korisnik_id(ki):
    conn = sqlite3.connect("upi_projekt.db")
    lista_kf = []
    try:
        cur = conn.cursor()
        cur.execute(" SELECT id_baze,opis,originalni_naslov,drzava,trajanje,zanr,glumac,film_id,korisnik_id FROM korisnik_film WHERE korisnik_id = ?", ([str(ki)]))        
        podaci = cur.fetchall()        
        for k in podaci:
            d = Korisnik_Film(k[0], k[1], k[2], k[3], k[4], k[5], k[6], k[7], k[8])
            lista_kf.append(d)

        print("uspjesno dohvaceni svi podaci iz tablice korisnik_film!")

        for p in lista_kf:
            print(p)

    except Exception as e: 
        print("Dogodila se greska pri dohvacanju svih podataka iz tablice korisnik_filma: ", e)
        conn.rollback()

    conn.close()
    return lista_kf

def dohvati_kf_po_film_id(ki):
    conn = sqlite3.connect("upi_projekt.db")
    lista_kf = []
    try:
        cur = conn.cursor()
        cur.execute(" SELECT id_baze,opis,originalni_naslov,drzava,trajanje,zanr,glumac,film_id,korisnik_id FROM korisnik_film WHERE film_id = ?", ([str(ki)]))      
        podaci = cur.fetchall()        
        for k in podaci:
            d = Korisnik_Film(k[0], k[1], k[2], k[3], k[4], k[5], k[6], k[7], k[8])
            lista_kf.append(d)

        print("uspjesno dohvaceni svi podaci iz tablice korisnik_film!")

        for p in lista_kf:
            print(p)

    except Exception as e: 
        print("Dogodila se greska pri dohvacanju svih podataka iz tablice korisnik_filma: ", e)
        conn.rollback()

    conn.close()
    return lista_kf

